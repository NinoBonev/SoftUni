package utils;

/**
 * Created by Nino Bonev - 31.7.2018 г., 20:52
 */
public class Constants {

    public static final String TERMINAL_COMMAND = "Quit";
    public static final int DIVIDER = 100;
}
