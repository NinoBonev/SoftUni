package onehitdungeon.interfaces;

public interface WeaponItem extends Item {
}
