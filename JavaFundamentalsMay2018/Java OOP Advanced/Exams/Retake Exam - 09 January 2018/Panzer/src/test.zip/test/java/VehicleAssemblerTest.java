import org.junit.Assert;
import org.mockito.Mockito;
import panzer.contracts.AttackModifyingPart;
import panzer.contracts.DefenseModifyingPart;
import panzer.contracts.HitPointsModifyingPart;
import panzer.models.miscellaneous.VehicleAssembler;

import java.math.BigDecimal;

/**
 * Created by Nino Bonev - 4.8.2018 г., 11:48
 */
public class VehicleAssemblerTest {
    private VehicleAssembler vehicleAssembler;
    private DefenseModifyingPart defenseModifyingPart;
    private AttackModifyingPart attackModifyingPart;
    private HitPointsModifyingPart hitPointsModifyingPart;

    @org.junit.Before
    public void setUp() throws Exception {
        this.vehicleAssembler = new VehicleAssembler();
        this.attackModifyingPart = Mockito.mock(AttackModifyingPart.class);
        this.defenseModifyingPart = Mockito.mock(DefenseModifyingPart.class);
        this.hitPointsModifyingPart = Mockito.mock(HitPointsModifyingPart.class);
        this.vehicleAssembler.addArsenalPart(this.attackModifyingPart);
        this.vehicleAssembler.addShellPart(defenseModifyingPart);
        this.vehicleAssembler.addEndurancePart(this.hitPointsModifyingPart);
    }

    @org.junit.Test
    public void getTotalWeight() {
        //Arrange
        Mockito.when(this.attackModifyingPart.getWeight()).thenReturn(10.0);
        Mockito.when(this.defenseModifyingPart.getWeight()).thenReturn(20.0);
        Mockito.when(this.hitPointsModifyingPart.getWeight()).thenReturn(30.0);
        //Act
        double actualWeight = this.vehicleAssembler.getTotalWeight();
        double expectedTotalWeight = 60.0;
        //Assert
        Assert.assertEquals(expectedTotalWeight, actualWeight, 0.1);
    }

    @org.junit.Test
    public void getTotalPrice() {
        Mockito.when(this.attackModifyingPart.getPrice()).thenReturn(BigDecimal.valueOf(100));
        Mockito.when(this.defenseModifyingPart.getPrice()).thenReturn(BigDecimal.valueOf(200));
        Mockito.when(this.hitPointsModifyingPart.getPrice()).thenReturn(BigDecimal.valueOf(3000));
        //Act
        BigDecimal actualPrice = this.vehicleAssembler.getTotalPrice();
        BigDecimal expectedTotalPrice = BigDecimal.valueOf(3300);
        //Assert
        Assert.assertEquals(0, actualPrice.compareTo(expectedTotalPrice));
    }

    @org.junit.Test
    public void getTotalAttackModification() {
        Mockito.when(this.attackModifyingPart.getAttackModifier()).thenReturn(201);

        Long actualAttackingModification = this.vehicleAssembler.getTotalAttackModification();
        Long expectedAttackingModification = 201L;

        Assert.assertEquals(expectedAttackingModification, actualAttackingModification, 0.1);
    }

    @org.junit.Test
    public void getTotalDefenseModification() {
        Mockito.when(this.defenseModifyingPart.getDefenseModifier()).thenReturn(201);

        Long actualDefenseModifier = this.vehicleAssembler.getTotalDefenseModification();
        Long expectedDefenseModifier = 201L;

        Assert.assertEquals(expectedDefenseModifier, actualDefenseModifier, 0.1);
    }

    @org.junit.Test
    public void getTotalHitPointModification() {
        Mockito.when(this.hitPointsModifyingPart.getHitPointsModifier()).thenReturn(201);

        Long actualHitPointsModifier = this.vehicleAssembler.getTotalHitPointModification();
        Long expectedHitPointsModifier = 201L;

        Assert.assertEquals(expectedHitPointsModifier, actualHitPointsModifier, 0.1);
    }

    @org.junit.Test
    public void addArsenalPart() {
        //Mockito.when(this.vehicleAssembler.addArsenalPart(this.attackModifyingPart))

    }

    @org.junit.Test
    public void addShellPart() {
    }

    @org.junit.Test
    public void addEndurancePart() {
    }
}