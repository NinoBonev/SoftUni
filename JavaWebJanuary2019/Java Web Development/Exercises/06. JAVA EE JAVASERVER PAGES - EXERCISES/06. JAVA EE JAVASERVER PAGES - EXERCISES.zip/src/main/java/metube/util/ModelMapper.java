package metube.util;

/**
 * Created by Nino Bonev - 7.2.2019 г., 18:28
 */
public class ModelMapper extends org.modelmapper.ModelMapper {
}
