package main.java.app.constants;

/**
 * Created by Nino Bonev - 3.8.2018 г., 16:00
 */
public class Constants {

    public static final String AUTHORIZATION = "Authorization";
    public static final String DATE = "Date";
    public static final String HOST = "Host";
    public static final String CONTENT_TYPE = "Content-Type";

}
