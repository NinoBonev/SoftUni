package hell.interfaces;

/**
 * Created by Nino Bonev - 19.8.2018 г., 19:03
 */
public interface HeroFactory {

    public Hero createHero(String name, String type);
}
