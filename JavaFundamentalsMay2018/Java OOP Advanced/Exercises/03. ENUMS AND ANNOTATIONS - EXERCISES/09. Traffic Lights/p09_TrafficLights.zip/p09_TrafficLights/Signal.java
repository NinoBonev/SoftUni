package p09_TrafficLights;

/**
 * Created by Nino Bonev - 24.7.2018 г., 16:12
 */
public enum Signal {
    RED, GREEN, YELLOW
}
