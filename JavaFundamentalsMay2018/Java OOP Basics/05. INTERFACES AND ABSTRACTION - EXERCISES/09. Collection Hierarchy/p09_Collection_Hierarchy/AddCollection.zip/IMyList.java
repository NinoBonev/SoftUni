package p09_Collection_Hierarchy;

/**
 * Created by Nino Bonev - 1.7.2018 г., 22:36
 */
public interface IMyList extends IAddRemoveCollection{
    int getUsed();
}
