import engine.Engine;

import java.io.IOException;


/**
 * Created by Nino Bonev - 18.7.2018 г., 21:20
 */
public class Main {
    public static void main(String[] args) throws IOException {

        Engine engine = new Engine();
        engine.run();

    }
}
