package cresla.entities.modules;

/**
 * Created by Nino Bonev - 3.8.2018 г., 8:42
 */
public class HeatProcessor extends BaseAbsorbing {

    public HeatProcessor(int id, int heatAbsorbing) {
        super(id, heatAbsorbing);
    }
}
