package coffeeMachine;

/**
 * Created by Nino Bonev - 20.7.2018 г., 13:01
 */
public enum CoffeeType {
    ESPRESSO, LATTE, IRISH
}
