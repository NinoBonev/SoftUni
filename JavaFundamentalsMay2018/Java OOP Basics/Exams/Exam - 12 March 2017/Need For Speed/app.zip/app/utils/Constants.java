package app.utils;

/**
 * Created by Nino Bonev - 11.7.2018 г., 23:55
 */
public final class Constants {

    private Constants() {}

    public static final String TERMINAL_COMMAND = "Cops Are Here";

    public static final String EMPTY_STRING = "";
    public static final Integer SHOW_CAR_STARS_DEFAULT_VALUE = 0;

}
