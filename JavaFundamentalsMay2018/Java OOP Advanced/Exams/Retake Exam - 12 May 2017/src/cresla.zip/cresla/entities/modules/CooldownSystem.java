package cresla.entities.modules;

/**
 * Created by Nino Bonev - 3.8.2018 г., 8:42
 */
public class CooldownSystem extends BaseAbsorbing{

    public CooldownSystem(int id, int heatAbsorbing) {
        super(id, heatAbsorbing);
    }
}
