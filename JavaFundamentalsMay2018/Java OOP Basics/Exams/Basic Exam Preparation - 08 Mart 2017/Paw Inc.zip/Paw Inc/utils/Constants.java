package utils;

/**
 * Created by Nino Bonev - 11.7.2018 г., 23:55
 */
public final class Constants {

    public static final String TERMINAL_COMMAND = "Paw Paw Pawah";

    private Constants() {}

    public static final String EMPTY_STRING = "";
}
