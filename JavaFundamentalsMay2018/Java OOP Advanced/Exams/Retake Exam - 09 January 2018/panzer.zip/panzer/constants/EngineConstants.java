package panzer.constants;

/**
 * Created by Nino Bonev - 1.8.2018 г., 19:02
 */
public class EngineConstants {


    public static final String TERMINAL_COMMAND = "Terminate";
}
