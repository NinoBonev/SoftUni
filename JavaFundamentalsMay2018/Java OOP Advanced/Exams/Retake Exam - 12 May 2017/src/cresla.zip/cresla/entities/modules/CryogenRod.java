package cresla.entities.modules;

/**
 * Created by Nino Bonev - 3.8.2018 г., 8:42
 */
public class CryogenRod extends BaseEnergy {

    public CryogenRod(int id, int energyOutput) {
        super(id, energyOutput);
    }
}
