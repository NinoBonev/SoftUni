package app;

import app.engine.Engine;

import java.io.IOException;

/**
 * Created by Nino Bonev - 14.7.2018 г., 8:48
 */
public class Main {
    public static void main(String[] args){

        Engine engine = new Engine();

        engine.run();
    }
}
