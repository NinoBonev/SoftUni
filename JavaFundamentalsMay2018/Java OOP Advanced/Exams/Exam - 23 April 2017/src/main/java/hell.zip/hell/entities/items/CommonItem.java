package hell.entities.items;

/**
 * Created by Nino Bonev - 19.8.2018 г., 11:15
 */
public class CommonItem extends BaseItem {
    public CommonItem(String name, Integer strengthBonus, Integer agilityBonus, Integer intelligenceBonus, Integer hitPointsBonus, Integer damageBonus) {
        super(name, strengthBonus, agilityBonus, intelligenceBonus, hitPointsBonus, damageBonus);
    }
}
