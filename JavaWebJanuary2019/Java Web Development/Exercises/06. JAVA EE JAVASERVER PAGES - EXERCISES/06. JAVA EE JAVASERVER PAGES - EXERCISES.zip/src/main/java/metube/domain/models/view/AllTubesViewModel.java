package metube.domain.models.view;

/**
 * Created by Nino Bonev - 7.2.2019 г., 20:33
 */
public class AllTubesViewModel {

    String name;

    public AllTubesViewModel() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
