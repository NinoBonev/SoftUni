package callofduty.interfaces;

public interface Mission extends Identifiable, Rateable, Bountyable {
}
