package io;

/**
 * Created by Nino Bonev - 11.7.2018 г., 18:06
 */
public class ConsoleWriter {

    public void writeLine(String line) {
        System.out.println(line);
    }
}
