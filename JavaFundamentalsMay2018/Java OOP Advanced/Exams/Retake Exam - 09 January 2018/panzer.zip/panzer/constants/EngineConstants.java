package panzer.constants;

/**
 * Created by Nino Bonev - 3.8.2018 г., 16:00
 */
public class EngineConstants {

    public static final String TERMINAL_COMMAND = "Terminate";
}
