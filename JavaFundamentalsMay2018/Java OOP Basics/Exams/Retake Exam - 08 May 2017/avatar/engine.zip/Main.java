import engine.Engine;

import java.io.IOException;

/**
 * Created by Nino Bonev - 31.7.2018 г., 18:44
 */
public class Main {
    public static void main(String[] args) throws IOException {

        Engine engine = new Engine();

        engine.run();
    }
}
