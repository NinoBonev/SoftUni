package main.java.app.contracts;

public interface InputReader {
    String readLine();
}